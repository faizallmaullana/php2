<?php

$username = $_POST['username'];
$password = $_POST['password'];

$tampilkan = "Usernamenya: ". $username. "<br>". "Passwordnya: ". $password;

echo $tampilkan;