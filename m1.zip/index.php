<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PWeb Pert 3</title>
</head>

<body>
  <div>
    <form action="">
      <div>
        <label for="username">Username</label><br>
        <input type="text" id="username_id" name="username">
      </div>

      <div>
        <label for="password">Password</label><br>
        <input type="password" id="password_id" name="password">
      </div>

      <div>
        <button type="button" onclick="button_clicked()">Submit</button>
      </div>
  </div>
  </form>
  </div>

  <br>

  <div id="hasil_id"></div>

</body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
  integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
  crossorigin="anonymous" referrerpolicy="no-referrer"></script>

  <script type="text/javascript">
    function button_clicked(){
      var username_value = $("#username_id").val()
      var password_value = $("#password_id").val()

      var my_data = {
        username:username_value,
        password:password_value
      }

      $.ajax({
        url:"login.php",
        type:"POST",
        data:my_data,
        success(data){
          // console.log(data)
          $("#hasil_id").html(data)
        }
      });
    }
  </script>
</html>